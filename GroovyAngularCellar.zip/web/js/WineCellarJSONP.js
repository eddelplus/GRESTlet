var app = angular.module('WineCellar', ['ngResource']);

app.config(['$routeProvider', function($routeProvider) {
    $routeProvider
        .when('/wine', {templateUrl: 'view_welcome.html'})
        .when('/wine/:id', {templateUrl: 'view_jsonp.html', controller: ViewCtrl})
        .otherwise({redirectTo:'/wine'});
    }]);

app.factory('WineResource', function($resource) {
    return $resource(
        'grest/wine/:id',
        { callback: 'JSON_CALLBACK' },
        { 
            get:   { method: 'JSONP' },
            query: { method: 'JSONP', isArray: true }
        }
    );
});

function GlobalCtrl($scope, WineResource) {
    
    $scope.winelist = WineResource.query();

}

function ViewCtrl($scope, $routeParams, WineResource) {

    $scope.wine = new WineResource();
    
    var id = $routeParams.id;
    if (id !== "new") {
        var list = $scope.winelist;
        var flag = false;
        for (var i = 0; i < list.length; i++) {
            if (list[i].id == id) {
                $scope.wine = list[i];
                flag = true;
            }
        }   
        if (!flag) {
            $scope.wine = WineResource.get({id: id});
        }
    }
    
}