import pool.H2Pool

def sql = H2Pool.getSql(context)

if (data.id) {
    // Update wine by exisgting id
    def stmt = 'update WINE set WINENAME=?, GRAPES=?, COUNTRY=?, REGION=?, VINTAGE=?, DESCRIPTION=? where ID=?'
    sql.executeUpdate(stmt, [
           data.name,
           data.grapes ?: null,
           data.country ?: null,
           data.region ?: null,
           data.year ?: null,
           data.description ?: null,
           data.id
        ]);
    json(data)
}
else {
    // Insert new wine
    def stmt = 'insert into WINE (WINENAME, GRAPES, COUNTRY, REGION, VINTAGE, DESCRIPTION) VALUES (?, ?, ?, ?, ?, ?)'
    def ids = sql.executeInsert(stmt, [
           data.name,
           data.grapes ?: null,
           data.country ?: null,
           data.region ?: null,
           data.year ?: null,
           data.description ?: null,
        ]);
    data.id = ids[0][0]
    json(data)
}
sql.close()
