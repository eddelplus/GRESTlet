import pool.H2Pool

def sql = H2Pool.getSql(context)

if (request.pathvar1) {
    // Get specific wine by id
    def row = null
    sql.eachRow('select * from WINE where ID=?', [ request.pathvar1 ] ) {
       row = [
           id:      it.ID,
           name:    it.WINENAME,
           year:    it.VINTAGE,
           grapes:  it.GRAPES,
           country: it.COUNTRY,
           region:  it.REGION,
           // Get content of clob type column
           description: it.DESCRIPTION?.characterStream?.text,
           picture: it.PICTURE
       ]
    }
    if (row)
        json(row)
    else
        response.sendError(404, "Resource not found")
}
else {
    // Query for all wines (id, name) only
    def rows = []
    sql.eachRow('select * from WINE order by WINENAME') {
       rows << [
           id:      it.ID,
           name:    it.WINENAME,
           year:    it.VINTAGE,
           grapes:  it.GRAPES,
           country: it.COUNTRY,
           region:  it.REGION,
           // Get content of clob type column
           description: it.DESCRIPTION?.characterStream?.text,
           picture: it.PICTURE
       ]
    }
    json(rows)  
}
sql.close()
