package pool

import org.h2.jdbcx.JdbcConnectionPool
import groovy.sql.Sql

class H2Pool {
    
    static pool = null
    
    static getSql(context) {
        
        if (pool) return Sql.newInstance(pool)
        
        String db = "jdbc:h2:" + context.getRealPath("/WEB-INF/cellar")
        pool = JdbcConnectionPool.create(db, "cellar", "cellar")
        
        def sql = Sql.newInstance(pool)
        // Create initial database unless it already exists
        if (!sql.firstRow("select * from INFORMATION_SCHEMA.TABLES where TABLE_NAME='WINE'")) {
            String script = context.getRealPath("/WEB-INF/cellar.sql")
            sql.execute("runscript from '${script}' charset 'UTF-8'")
        }
        return sql
    }
}
