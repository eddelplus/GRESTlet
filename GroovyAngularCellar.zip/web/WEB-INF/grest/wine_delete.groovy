import pool.H2Pool

if (request.pathvar1) {
    // Delete specific wine by id
    def sql = H2Pool.getSql(context)
    def stmt = 'delete from WINE where ID=?'
    if (sql.executeUpdate(stmt, [request.pathvar1]) > 0)
        response.setStatus(204, "successfully deleted")
    else
        response.setStatus(404, "nothing deleted")
    sql.close()
}
